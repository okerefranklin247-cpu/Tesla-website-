const navbar = document.getElementById('navbar');
const menuToggle = document.getElementById('menuToggle');
const nav = document.getElementById('nav');
const orderForm = document.getElementById('orderForm');

window.addEventListener('scroll', () => {
  navbar.classList.toggle('scrolled', window.scrollY > 30);
});

menuToggle?.addEventListener('click', () => {
  navbar.classList.toggle('mobile-open');
});

document.querySelectorAll('#nav a').forEach(link => {
  link.addEventListener('click', () => navbar.classList.remove('mobile-open'));
});

document.querySelectorAll('[data-model]').forEach(button => {
  button.addEventListener('click', () => {
    const model = button.dataset.model;
    const vehicle = document.querySelector('#orderForm select[name="vehicle"]');
    if (vehicle && ['Model Y', 'Cybertruck', 'Model S', 'Model X'].includes(model)) {
      vehicle.value = model;
      document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
    } else {
      document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
    }
  });
});

orderForm?.addEventListener('submit', event => {
  event.preventDefault();

  const data = new FormData(orderForm);
  const message =
`TESLA ORDER REQUEST

Customer: ${data.get('name')}
Phone/WhatsApp: ${data.get('phone')}
Email: ${data.get('email') || 'Not provided'}
Vehicle: ${data.get('vehicle')}
Quantity: ${data.get('quantity')}
Delivery location: ${data.get('delivery')}
Payment: Bank transfer
Prices: Available on request
Additional details: ${data.get('details') || 'None'}`;

  const whatsappNumber = '2347040642209';
  window.open(`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`, '_blank');
});
